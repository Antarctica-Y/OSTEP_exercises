#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

void main() {
    int f, vid;
    f = open("./text.txt", O_RDWR);
    vid = fork();
    if (vid == 0) {
        printf("This is file %d from child\n", f);
    } else if (vid > 0) {
        printf("This is file %d from father\n", f);
    } else {
        printf("Error!");
    }
    if (vid == 0) {
        write(f, "This is text from child\n", 20);
    } else if (vid > 0) {
        write(f, "This is text from father\n", 25);
    } else {
        printf("Error!");
    }
    close(f);
}
