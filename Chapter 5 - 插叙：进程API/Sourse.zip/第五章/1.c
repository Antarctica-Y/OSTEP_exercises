#include <stdio.h>
#include <unistd.h>

void main() {
    int pid = -1;
    int x = 100;
    pid = fork();

    if (pid < 0) {
        printf("Error!");
    } else if (pid == 0) {
        printf("This is child, my pid is %d, my init_value of x is %d \n", pid, x);
        x = 2222;
        printf("This is child, my pid is %d, my change_value of x is %d \n", pid, x);
    } else if (pid > 0) {
        printf("This is father, my pid is %d, my value of x is %d \n", pid, x);
        x = 3333;
        printf("This is father, my pid is %d, my change_value of x is %d \n", pid, x);
    }
}
