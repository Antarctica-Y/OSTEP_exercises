#include <stdio.h>
#include <unistd.h>

void main() {
    int vid;
    vid = fork();
    if (vid == 0) {
        printf("This is child\n");
        close(1);
        printf("Already close the stdout");
    } else if (vid > 0) {
        printf("This is father\n");
    }
}