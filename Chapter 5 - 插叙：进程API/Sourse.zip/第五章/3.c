#include <stdio.h>
#include <unistd.h>

void main(){
    int vid;
    vid = vfork();
    if (vid == 0){
        printf("Hello\n");
        _exit(0);
    }else if(vid > 0){
        printf("goodbye\n");
    }
}