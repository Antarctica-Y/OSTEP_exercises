#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void main() {
    int p[2], vid, backup;
    char inbuf[19];
    if (pipe(p) < 0) exit(1);
    vid = fork();
    if (vid == 0) {
        printf("This is child\n");
        dup2(1, backup);
        close(1);
        printf("Try\n");
        write(p[1], "trans_imformation\n", 19);
        dup2(backup, 1);
        printf("used pip\n");
    } else if (vid > 0) {
        wait(NULL);
        read(p[0], inbuf, 19);
        printf("%s\n", inbuf);
        printf("This is father\n");
    }
}
