#include <stdio.h>
#include <unistd.h>

void main(int argc, char *argv[], char *envp[]) {
    int vid;
    vid = vfork();
    if (vid == 0) {
        printf("This is child\n");
    } else if (vid > 0) {
        char *argv[] = {"ls", "-l", NULL};
        char *path = "/bin/ls";

        execl(path, "ls", "-l", NULL);
        execlp("ls", "-l", NULL);
        execle(path, "ls", "-l", NULL, envp);

        execv(path, argv);
        execvp(path, argv);
        execve(path, argv, envp);

    }
}
