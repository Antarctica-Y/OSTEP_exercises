#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void main(){
    int vid, pid, status;
    vid = fork();
    if(vid == 0){
        printf("i am child, my id is %d\n", vid);
        pid = wait(&status);
        printf("alright, i am child, i am using the wait(), its namber is %d\n", pid);
    }else if (vid > 0){
        printf("i am father, my id is %d,it's time to wait child...\n", vid);
        pid = wait(&status);
        printf("alright, i am father, my child is over, its namber is %d\n", pid);
    }

}

